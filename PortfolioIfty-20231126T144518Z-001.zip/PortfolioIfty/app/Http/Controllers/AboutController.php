<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AboutController extends Controller
{
    public function index()
    {
        // You can fetch data from a database, an API, or use hardcoded data here
        $name = 'Your Name';
        $description = 'A passionate web developer with a focus on Laravel.';
        $education = 'Your Education Details';
        $workExperience = 'Your Work Experience Details';
        $certifications = 'Your Certifications Details';

        return view('about.index', compact('name', 'description', 'education', 'workExperience', 'certifications'));
    }
}

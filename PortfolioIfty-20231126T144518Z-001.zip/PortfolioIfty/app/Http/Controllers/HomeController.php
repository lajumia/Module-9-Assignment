<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $name = 'Your Name';
        $summary = 'A passionate web developer with a focus on Laravel.';

        return view('home.index', compact('name', 'summary'));
    }
}


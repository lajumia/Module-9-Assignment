
<footer>
    <p>&copy; 2023 Your Portfolio</p>
</footer>

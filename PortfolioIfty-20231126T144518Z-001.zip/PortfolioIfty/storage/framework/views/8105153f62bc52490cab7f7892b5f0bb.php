
<footer>
    <p>&copy; 2023 Your Portfolio</p>
</footer>
<?php /**PATH D:\PS\Ostad\Ostad_assg_mod_9_laravel_project\PortfolioIfty\resources\views/partials/footer.blade.php ENDPATH**/ ?>
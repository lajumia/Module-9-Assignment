

<?php $__env->startSection('title', 'Projects'); ?>

<?php $__env->startSection('content'); ?>
    <header>
        <h1>Projects</h1>
    </header>

    <section>
        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="project">
                <h2><?php echo e($project->title); ?></h2>
                <p><?php echo e($project->description); ?></p>
                <?php if($project->image): ?>
                    <img src="<?php echo e($project->image); ?>" alt="<?php echo e($project->title); ?>">
                <?php endif; ?>
                <?php if($project->url): ?>
                    <p><a href="<?php echo e($project->url); ?>" target="_blank">Visit Project</a></p>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No projects available.</p>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PS\Ostad\Ostad_assg_mod_9_laravel_project\PortfolioIfty\resources\views/projects/index.blade.php ENDPATH**/ ?>
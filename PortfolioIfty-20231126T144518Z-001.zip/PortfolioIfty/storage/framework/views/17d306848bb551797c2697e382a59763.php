

<?php $__env->startSection('title', 'Contact Me'); ?>

<?php $__env->startSection('content'); ?>
    <header>
        <h1>Contact Me</h1>
        <p>Have a question or want to collaborate? Feel free to reach out!</p>
    </header>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <section>
        <form action="/contact" method="post">
            <?php echo csrf_field(); ?>
            <label for="name">Name:</label>
            <input type="text" name="name" id="name" required>

            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>

            <label for="message">Message:</label>
            <textarea name="message" id="message" rows="4" required></textarea>

            <button type="submit">Send Message</button>
        </form>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PS\Ostad\Ostad_assg_mod_9_laravel_project\PortfolioIfty\resources\views/contact/index.blade.php ENDPATH**/ ?>
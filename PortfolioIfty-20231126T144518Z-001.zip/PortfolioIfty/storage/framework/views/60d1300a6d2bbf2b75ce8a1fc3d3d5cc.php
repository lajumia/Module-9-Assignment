

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <header>
        <h1>Welcome to My Portfolio</h1>
    </header>

    <section>
        <h2>About Me</h2>
        <p>
            Hi, I'm <?php echo e($name); ?>. <?php echo e($summary); ?>

        </p>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PS\Ostad\Ostad_assg_mod_9_laravel_project\PortfolioIfty\resources\views/home/index.blade.php ENDPATH**/ ?>